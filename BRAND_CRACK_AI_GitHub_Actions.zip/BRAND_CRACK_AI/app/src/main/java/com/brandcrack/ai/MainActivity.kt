package com.brandcrack.ai

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF030711)
private val CardBg = Color(0xFF081321)
private val Cyan = Color(0xFF00E5FF)
private val Blue = Color(0xFF176BFF)
private val Violet = Color(0xFF8B35FF)
private val Green = Color(0xFF00E6A0)
private val Muted = Color(0xFF8EA7BB)
private val dbUrl = "https://free-hack-d53a4-default-rtdb.firebaseio.com/"
private const val DEFAULT_GAME_URL = "https://hgnice.cc/#/register?invitationCode=21672919307"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (FirebaseApp.getApps(this).isEmpty()) {
            val options = FirebaseOptions.Builder().setApplicationId("1:000000000000:android:brandcrack-placeholder").setApiKey("CONFIGURE_FIREBASE_API_KEY").setDatabaseUrl(dbUrl).build()
            FirebaseApp.initializeApp(this, options)
        }
        window.statusBarColor = android.graphics.Color.rgb(3, 7, 17)
        window.navigationBarColor = android.graphics.Color.rgb(3, 7, 17)
        setContent { BrandCrackApp() }
    }
}

@Composable
private fun BrandCrackApp() {
    val context = LocalContext.current
    val auth = remember { FirebaseAuth.getInstance() }
    var screen by remember { mutableStateOf(if (auth.currentUser != null) "Home" else "Login") }
    var username by remember { mutableStateOf(auth.currentUser?.email.orEmpty()) }
    var license by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var brandName by remember { mutableStateOf("BRAND CRACK AI") }
    var brandLogo by remember { mutableStateOf("") }
    var telegram by remember { mutableStateOf("") }
    var gameUrl by remember { mutableStateOf("") }
    var blocked by remember { mutableStateOf(false) }
    var ocrText by remember { mutableStateOf("") }
    var captureApproved by remember { mutableStateOf(false) }
    var records by remember { mutableStateOf(loadRecords(context)) }
    var selectedTab by remember { mutableStateOf("Home") }

    DisposableEffect(Unit) {
        val ref = FirebaseDatabase.getInstance(dbUrl).getReference("falcon_config")
        val listener = object : com.google.firebase.database.ValueEventListener {
            override fun onDataChange(snapshot: com.google.firebase.database.DataSnapshot) {
                brandName = snapshot.child("brand_name").getValue(String::class.java) ?: "BRAND CRACK AI"
                brandLogo = snapshot.child("brand_logo").getValue(String::class.java).orEmpty()
                telegram = snapshot.child("tg_link").getValue(String::class.java).orEmpty()
                gameUrl = snapshot.child("game_url").getValue(String::class.java) ?: DEFAULT_GAME_URL
            }
            override fun onCancelled(error: com.google.firebase.database.DatabaseError) { message = "Firebase config unavailable: ${error.message}" }
        }
        ref.addValueEventListener(listener)
        onDispose { ref.removeEventListener(listener) }
    }

    val projectionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            captureApproved = true
            val serviceIntent = Intent(context, CaptureService::class.java).apply {
                putExtra("resultCode", result.resultCode)
                putExtra("resultData", result.data)
            }
            androidx.core.content.ContextCompat.startForegroundService(context, serviceIntent)
            message = "Permission granted. Android capture service started; live frame extraction is not yet wired in this build."
        } else { captureApproved = false; message = "Screen capture permission was not granted." }
    }
    val imageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            try {
                val image = InputImage.fromFilePath(context, uri)
                TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
                    .addOnSuccessListener { result ->
                        ocrText = result.text.ifBlank { "No readable text detected in this image." }
                        message = "OCR finished. Review the extracted text before requesting analysis."
                    }.addOnFailureListener { message = "OCR failed: ${it.localizedMessage ?: "unknown error"}" }
            } catch (e: Exception) { message = "Could not open image: ${e.localizedMessage}" }
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Cyan, background = Bg, surface = CardBg, onBackground = Color.White, onSurface = Color.White)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF07152A), Bg, Color(0xFF02040A))))) {
            if (screen == "Login") {
                LoginScreen(brandName, license, { license = it }, password, { password = it }, showPassword, { showPassword = it }, busy, message,
                    onLogin = {
                        if (license.isBlank() || password.isBlank()) { message = "Enter your Firebase Authentication email/license and password." }
                        else {
                            busy = true; message = "Connecting securely…"
                            auth.signInWithEmailAndPassword(license.trim(), password).addOnCompleteListener { task ->
                                busy = false
                                if (task.isSuccessful) {
                                    username = license.trim()
                                    FirebaseDatabase.getInstance(dbUrl).getReference("users").child(license.substringBefore('@').lowercase()).get()
                                        .addOnSuccessListener { user ->
                                            blocked = user.child("is_blocked").getValue(Boolean::class.java) == true
                                            if (blocked) { auth.signOut(); message = "This account is blocked by the administrator." }
                                            else {
                                                user.ref.updateChildren(mapOf("name" to license.trim(), "last_login" to System.currentTimeMillis()))
                                                screen = "Home"; selectedTab = "Home"; message = "Signed in successfully."
                                            }
                                        }.addOnFailureListener { message = "Signed in, but user access status could not be verified: ${it.localizedMessage}"; auth.signOut() }
                                } else message = "Login failed: ${task.exception?.localizedMessage ?: "check credentials and Firebase Auth setup"}"
                            }
                        }
                    })
            } else {
                Column(Modifier.fillMaxSize()) {
                    Header(brandName, onSettings = { screen = "Settings" })
                    when (selectedTab) {
                        "Home" -> HomeScreen(onScan = { selectedTab = "Scan" }, onAnalysis = { selectedTab = "Analysis" }, onHistory = { selectedTab = "History" }, onProfile = { selectedTab = "Profile" }, message = message)
                        "Scan" -> ScanScreen(captureApproved, ocrText, message,
                            onCapture = { message = "Android will show its system screen-sharing prompt."; val mgr = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager; projectionLauncher.launch(mgr.createScreenCaptureIntent()) },
                            onPickImage = { imageLauncher.launch("image/*") }, onStop = { context.stopService(Intent(context, CaptureService::class.java)); captureApproved = false; message = "Capture service stopped." })
                        "Analysis" -> AnalysisScreen(ocrText, message, onAnalyze = {
                            val report = if (ocrText.isBlank()) "Insufficient data for a reliable signal. Import a chart screenshot and extract readable text first. No market prediction was generated." else "OCR evidence extracted:\n$ocrText\n\nThis build does not call an AI backend yet. No direction, price, indicator, or confidence score is inferred without a configured and secured analysis service."
                            records = (listOf(ScanRecord("Analysis", report, System.currentTimeMillis())) + records).take(50); saveRecords(context, records); message = "Evidence report saved locally."
                        })
                        "History" -> HistoryScreen(records, onDelete = { record -> records = records.filterNot { it.id == record.id }; saveRecords(context, records) })
                        "Profile" -> ProfileScreen(username, onSettings = { screen = "Settings" }, onLogout = { auth.signOut(); screen = "Login"; selectedTab = "Home"; password = "" })
                    }
                    Spacer(Modifier.weight(1f))
                    BottomNav(selectedTab) { selectedTab = it }
                }
            }
            if (screen == "Settings") SettingsScreen(brandName, telegram, gameUrl, onBack = { screen = if (auth.currentUser == null) "Login" else "Home" })
        }
    }
}

@Composable private fun Header(name: String, onSettings: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        WolfMark(44); Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)) {
            Text(name.uppercase(), color = Cyan, fontWeight = FontWeight.Black, fontSize = 17.sp)
            Text("AI POWERED MARKET SCANNER", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
        }
        IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, null, tint = Color.White) }
    }
}

@Composable private fun LoginScreen(name: String, license: String, onLicense: (String) -> Unit, password: String, onPassword: (String) -> Unit, show: Boolean, onShow: (Boolean) -> Unit, busy: Boolean, message: String, onLogin: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 26.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        WolfMark(104); Spacer(Modifier.height(14.dp)); Text(name.uppercase(), fontSize = 27.sp, fontWeight = FontWeight.Black, color = Cyan, textAlign = TextAlign.Center)
        Text("AI POWERED MARKET SCANNER", color = Violet, fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(32.dp)); Text("WELCOME BACK", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp)
        Text("Sign in with your configured Firebase Authentication account", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp, bottom = 18.dp))
        NeonInput(license, onLicense, "License Name / Auth Email", false) ; Spacer(Modifier.height(10.dp))
        NeonInput(password, onPassword, "Password", true, show, onShow)
        Spacer(Modifier.height(20.dp)); NeonButton(if (busy) "CONNECTING…" else "LOGIN", onLogin, Modifier.fillMaxWidth(), enabled = !busy)
        if (message.isNotBlank()) Text(message, color = if (message.contains("success", true)) Green else Color(0xFFFF8B9A), fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 14.dp))
        Spacer(Modifier.height(30.dp)); Text("SECURE SIGN-IN • FIREBASE AUTH", color = Muted, fontSize = 10.sp)
    }
}

@Composable private fun HomeScreen(onScan: () -> Unit, onAnalysis: () -> Unit, onHistory: () -> Unit, onProfile: () -> Unit, message: String) {
    LazyColumn(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        item { Spacer(Modifier.height(4.dp)); Row(verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(8.dp).background(Green, CircleShape)); Text("  SYSTEM READY", color = Green, fontSize = 11.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.weight(1f)); Text("AI • OCR", color = Muted, fontSize = 11.sp) } }
        item { NeonCard {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(vertical = 22.dp)) {
                Box(Modifier.size(88.dp).border(2.dp, Cyan, CircleShape).background(Color(0xFF061A2B), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.CenterFocusStrong, null, tint = Cyan, modifier = Modifier.size(44.dp)) }
                Spacer(Modifier.height(16.dp)); Text("MARKET SCANNER", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Black)
                Text("Screen Capture • OCR • Evidence", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp, bottom = 18.dp))
                NeonButton("SCAN SCREEN", onScan, Modifier.fillMaxWidth())
            } }
        } }
        item { ActionCard(Icons.Default.AutoAwesome, "AI ANALYSIS", "Review extracted evidence and reports", Violet, onAnalysis) }
        item { ActionCard(Icons.Default.History, "HISTORY", "Open saved analysis reports", Blue, onHistory) }
        item { ActionCard(Icons.Default.Person, "PROFILE", "Account status and session", Cyan, onProfile) }
        if (message.isNotBlank()) item { Text(message, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(4.dp)) }
        item { Text("Analysis depends on actual input. No guaranteed outcomes or fabricated accuracy scores.", color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(10.dp)) }
    }
}

@Composable private fun ScanScreen(captureApproved: Boolean, ocrText: String, message: String, onCapture: () -> Unit, onPickImage: () -> Unit, onStop: () -> Unit) {
    LazyColumn(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("SCREEN SCANNING", color = Cyan, fontSize = 20.sp, fontWeight = FontWeight.Black) }
        item { NeonCard { Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.ScreenShare, null, tint = Cyan, modifier = Modifier.size(54.dp)); Spacer(Modifier.height(10.dp))
            Text(if (captureApproved) "CAPTURE PERMISSION GRANTED" else "SCREEN CAPTURE", color = Color.White, fontWeight = FontWeight.Bold)
            Text("Android displays its own consent dialog. Capture must be started by you.", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(vertical = 10.dp))
            NeonButton("START SCREEN CAPTURE", onCapture, Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp)); NeonButton("STOP CAPTURE", onStop, Modifier.fillMaxWidth(), secondary = true)
            Spacer(Modifier.height(8.dp)); NeonButton("IMPORT CHART SCREENSHOT FOR OCR", onPickImage, Modifier.fillMaxWidth(), secondary = true)
        } } }
        item { NeonCard { Column(Modifier.padding(14.dp)) { Text("DETECTED TEXT (OCR)", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 13.sp); Spacer(Modifier.height(8.dp)); Text(ocrText.ifBlank { "No OCR results yet. Import a screenshot to extract visible text." }, color = if (ocrText.isBlank()) Muted else Color.White, fontSize = 12.sp) } } }
        if (message.isNotBlank()) item { Text(message, color = Muted, fontSize = 12.sp) }
    }
}

@Composable private fun AnalysisScreen(ocrText: String, message: String, onAnalyze: () -> Unit) {
    LazyColumn(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        item { Text("AI ANALYSIS REPORT", color = Cyan, fontSize = 20.sp, fontWeight = FontWeight.Black) }
        item { NeonCard { Column(Modifier.padding(16.dp)) { Text("EVIDENCE STATUS", color = Cyan, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); Text(if (ocrText.isBlank()) "Insufficient data for a reliable signal." else "OCR text is available for review. AI backend is not configured in this source build.", color = Color.White, fontSize = 14.sp); Spacer(Modifier.height(12.dp)); Text("No fabricated price, indicator, direction, or confidence score is shown.", color = Muted, fontSize = 12.sp) } } }
        item { NeonButton("CREATE EVIDENCE REPORT", onAnalyze, Modifier.fillMaxWidth()) }
        if (message.isNotBlank()) item { Text(message, color = Muted, fontSize = 12.sp) }
        if (ocrText.isNotBlank()) item { NeonCard { Column(Modifier.padding(14.dp)) { Text("OCR INPUT", color = Cyan, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp)); Text(ocrText, color = Color.White, fontSize = 12.sp) } } }
    }
}

@Composable private fun HistoryScreen(records: List<ScanRecord>, onDelete: (ScanRecord) -> Unit) {
    LazyColumn(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("HISTORY & REPORTS", color = Cyan, fontSize = 20.sp, fontWeight = FontWeight.Black) }
        if (records.isEmpty()) item { NeonCard { Text("No saved reports yet. Create a report from the Analysis screen.", color = Muted, modifier = Modifier.padding(18.dp)) } }
        items(records, key = { it.id }) { record -> NeonCard { Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Text(record.title, color = Cyan, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); IconButton(onClick = { onDelete(record) }) { Icon(Icons.Default.DeleteOutline, null, tint = Color(0xFFFF7185)) } }
            Text(SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(record.time)), color = Muted, fontSize = 10.sp)
            Spacer(Modifier.height(8.dp)); Text(record.body.take(650), color = Color.White, fontSize = 12.sp)
        } } }
    }
}

@Composable private fun ProfileScreen(email: String, onSettings: () -> Unit, onLogout: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PROFILE", color = Cyan, fontSize = 20.sp, fontWeight = FontWeight.Black)
        NeonCard { Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) { WolfMark(72); Spacer(Modifier.height(12.dp)); Text("SIGNED-IN ACCOUNT", color = Cyan, fontWeight = FontWeight.Bold); Text(email, color = Color.White, fontSize = 13.sp); Text("Account status is checked against the legacy users node where permitted.", color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 10.dp)) } }
        NeonButton("SETTINGS", onSettings, Modifier.fillMaxWidth(), secondary = true); NeonButton("LOG OUT", onLogout, Modifier.fillMaxWidth())
    }
}

@Composable private fun SettingsScreen(name: String, telegram: String, gameUrl: String, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Bg).padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Cyan) }; Text("SETTINGS", color = Cyan, fontSize = 20.sp, fontWeight = FontWeight.Black) }
        Spacer(Modifier.height(12.dp))
        listOf("Brand" to name, "Firebase" to "Existing Realtime Database", "Authentication" to "Firebase Auth required", "AI Provider" to "Not configured", "Scan Quality" to "Standard", "Language" to "English", "Notifications" to "Not configured", "Telegram link" to telegram.ifBlank { "Not configured" }, "Game URL" to gameUrl.ifBlank { "Not configured" }, "About" to "BRAND CRACK AI v1.0.0").forEach { (title, value) -> NeonCard { Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Column { Text(title, color = Color.White, fontWeight = FontWeight.SemiBold); Text(value, color = Muted, fontSize = 11.sp) } } }; Spacer(Modifier.height(8.dp)) }
    }
}

@Composable private fun BottomNav(selected: String, onSelect: (String) -> Unit) {
    val items = listOf("Home" to Icons.Default.Home, "Scan" to Icons.Default.CenterFocusStrong, "Analysis" to Icons.Default.AutoAwesome, "History" to Icons.Default.History, "Profile" to Icons.Default.Person)
    Row(Modifier.fillMaxWidth().background(Color(0xFF050D18)).border(1.dp, Color(0xFF123B55)).padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
        items.forEach { (label, icon) -> Column(Modifier.weight(1f).clickable { onSelect(label) }.padding(vertical = 3.dp), horizontalAlignment = Alignment.CenterHorizontally) { Icon(icon, null, tint = if (selected == label) Cyan else Muted, modifier = Modifier.size(22.dp)); Text(label, color = if (selected == label) Cyan else Muted, fontSize = 9.sp) } }
    }
}

@Composable private fun ActionCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, accent: Color, onClick: () -> Unit) {
    NeonCard { Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(15.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = accent, modifier = Modifier.size(30.dp)); Spacer(Modifier.width(14.dp)); Column(Modifier.weight(1f)) { Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp); Text(subtitle, color = Muted, fontSize = 11.sp) }; Icon(Icons.Default.ChevronRight, null, tint = accent) } }
}

@Composable private fun NeonCard(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().border(1.dp, Brush.linearGradient(listOf(Cyan.copy(alpha = .75f), Blue.copy(alpha = .45f), Violet.copy(alpha = .7f))), RoundedCornerShape(18.dp)).background(Brush.verticalGradient(listOf(Color(0xFF0A1B2D), CardBg)), RoundedCornerShape(18.dp)), content = content)
}

@Composable private fun NeonButton(label: String, onClick: () -> Unit, modifier: Modifier = Modifier, secondary: Boolean = false, enabled: Boolean = true) {
    Box(modifier.fillMaxWidth().then(if (secondary) Modifier.background(Color(0xFF0B1A2B), RoundedCornerShape(12.dp)) else Modifier.background(Brush.horizontalGradient(listOf(Cyan, Blue, Violet)), RoundedCornerShape(12.dp))).border(1.dp, if (secondary) Cyan.copy(alpha = .7f) else Color.Transparent, RoundedCornerShape(12.dp)).clickable(enabled = enabled, onClick = onClick).padding(vertical = 14.dp), contentAlignment = Alignment.Center) { Text(label, color = Color.White, fontWeight = FontWeight.Black, fontSize = 12.sp, letterSpacing = .6.sp) }
}

@Composable private fun NeonInput(value: String, onValue: (String) -> Unit, label: String, isPassword: Boolean, show: Boolean = false, onShow: (Boolean) -> Unit = {}) {
    OutlinedTextField(value = value, onValueChange = onValue, modifier = Modifier.fillMaxWidth(), label = { Text(label, color = Muted) }, singleLine = true,
        visualTransformation = if (isPassword && !show) androidx.compose.ui.text.input.PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        trailingIcon = if (isPassword) ({ IconButton(onClick = { onShow(!show) }) { Icon(if (show) Icons.Default.VisibilityOff else Icons.Default.Visibility, null, tint = Cyan) } }) else null,
        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = Color(0xFF23455E), focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedLabelColor = Cyan, unfocusedLabelColor = Muted, cursorColor = Cyan))
}

@Composable private fun WolfMark(size: Int) {
    Box(Modifier.size(size.dp).border(1.5.dp, Brush.linearGradient(listOf(Cyan, Violet)), RoundedCornerShape(22.dp)).background(Color(0xFF06101D), RoundedCornerShape(22.dp)), contentAlignment = Alignment.Center) {
        Text("◈", color = Cyan, fontSize = (size * .48).sp, fontWeight = FontWeight.Black)
        Text("W", color = Violet, fontSize = (size * .25).sp, fontWeight = FontWeight.Black)
    }
}

data class ScanRecord(val title: String, val body: String, val time: Long, val id: String = "${time}_${body.hashCode()}")
private fun loadRecords(context: Context): List<ScanRecord> = try {
    val array = JSONArray(context.getSharedPreferences("reports", Context.MODE_PRIVATE).getString("items", "[]"))
    (0 until array.length()).map { val o = array.getJSONObject(it); ScanRecord(o.getString("title"), o.getString("body"), o.getLong("time"), o.getString("id")) }
} catch (_: Exception) { emptyList() }
private fun saveRecords(context: Context, records: List<ScanRecord>) {
    val array = JSONArray(); records.forEach { array.put(JSONObject().put("title", it.title).put("body", it.body).put("time", it.time).put("id", it.id)) }
    context.getSharedPreferences("reports", Context.MODE_PRIVATE).edit().putString("items", array.toString()).apply()
}
