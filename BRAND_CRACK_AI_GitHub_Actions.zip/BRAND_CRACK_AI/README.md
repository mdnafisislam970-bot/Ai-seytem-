# BRAND CRACK AI — Android source project

Native Android project using Kotlin, Jetpack Compose, Material 3, Firebase SDKs, and ML Kit OCR.

## Build the APK with GitHub Actions (phone-friendly)

1. Download and extract `BRAND_CRACK_AI_Source.zip`.
2. Create a GitHub repository and upload the **contents inside** the `BRAND_CRACK_AI` folder. The repository root must contain `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `app/`, and `.github/workflows/android.yml`.
3. Open the repository's **Actions** tab. If GitHub asks to enable Actions, enable it.
4. Push/commit the files to `main` or `master`, or open **Actions → BRAND CRACK AI Android Build → Run workflow**.
5. Wait for the job to finish. A green check means the Gradle debug build completed. If it fails, open the failed step and copy the first `e:` / `Execution failed` error for diagnosis.
6. Open the successful workflow run, scroll to **Artifacts**, and download `BRAND-CRACK-AI-debug-apk`. Extract it to get `app-debug.apk`.
7. Transfer the APK to your Android phone and install it. Android may ask you to allow installation from that source.

The workflow uses Ubuntu, JDK 17, and Gradle 8.11.1, compatible with Android Gradle Plugin 8.9.2. It builds a **debug APK**, not a signed Play Store release.

## Local Android Studio build

Open this folder in Android Studio, allow Gradle sync, then choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**. The debug APK is normally written to `app/build/outputs/apk/debug/app-debug.apk`.

## Firebase configuration — important

The app targets the existing Realtime Database URL:

`https://free-hack-d53a4-default-rtdb.firebaseio.com/`

The source reads `falcon_config/brand_name`, `brand_logo`, `tg_link`, and `game_url`, and checks `users/{username}/is_blocked`. Firebase Authentication must have Email/Password enabled and matching accounts provisioned. Configure Realtime Database Security Rules so authenticated users can read only the required records and users cannot write privileged fields. Never make the database publicly writable.

The current source contains placeholder Firebase application/API configuration, so a successful APK build does **not** mean Firebase login will work. Configure a real Android Firebase app and its `google-services.json`, then apply the official Google Services Gradle plugin and Firebase setup as needed. Do not commit secrets or administrator credentials.

Legacy HTML uses one shared `falcon_config/password` field. The native app intentionally does not use that value as a secure universal password; migrate users to Firebase Authentication and server-enforced access checks.

## Current feature status

- Implemented UI: login, dashboard, scan screen, analysis/evidence report, local history, profile, settings.
- Image import and ML Kit OCR are wired for user-selected images.
- Android MediaProjection consent and foreground-service start/stop are present; live frame extraction/preview is not implemented yet.
- AI backend requests are not implemented; analysis currently reports OCR evidence and explicitly avoids invented predictions.
- Firebase project configuration, Authentication users, and database rules must be configured and tested separately.

A green GitHub build confirms compilation only. Test the app on a real device and verify Firebase rules before treating it as production-ready.
